﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lista_zadanie
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Mieszkania> mieszkania = new List<Mieszkania>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            OdczytajDaneZPliku("dane.txt");
            OdswiezListeMieszkan();
        }

        private void OdswiezListeMieszkan()
        {
            listViewMieszkania.Items.Clear();
            foreach (var Mieszkania in mieszkania)
            {
                listViewMieszkania.Items.Add(Mieszkania);
            }
        }

        private void ZapiszDaneDoPliku(string nazwaPliku)
        {
            using (StreamWriter writer = new StreamWriter(nazwaPliku))
            {
                foreach (var Mieszkania in mieszkania)
                {
                    writer.WriteLine($"{Mieszkania.Id},{Mieszkania.Osiedle},{Mieszkania.Adres},{Mieszkania.ZGarazem},{Mieszkania.Rodzaj},{Mieszkania.Metraz},{Mieszkania.Dostepnosc},{Mieszkania.Opis}");
                }
            }
        }

        private void OdczytajDaneZPliku(string nazwaPliku)
        {
            mieszkania.Clear();
            if (File.Exists(nazwaPliku))
            {
                using (StreamReader reader = new StreamReader(nazwaPliku))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] parts = line.Split(',');
                        if (parts.Length == 8)
                        {
                            Mieszkania Mieszkania = new Mieszkania();
                            Mieszkania.Id = int.Parse(parts[0]);
                            Mieszkania.Osiedle = parts[1];
                            Mieszkania.Adres = parts[2];
                            Mieszkania.ZGarazem = bool.Parse(parts[3]);
                            Mieszkania.Rodzaj = (RodzajMieszkania)Enum.Parse(typeof(RodzajMieszkania), parts[4]);
                            Mieszkania.Metraz = int.Parse(parts[5]);
                            Mieszkania.Dostepnosc = bool.Parse(parts[6]);
                            Mieszkania.Opis = parts[7];
                            mieszkania.Add(Mieszkania);
                        }
                    }
                }
            }
        }

        private void ZapiszToolStripMenuItem_Click(object sender, RoutedEventArgs e)
        {
            ZapiszDaneDoPliku("dane.txt");
        }

        private void PobierzToolStripMenuItem_Click(object sender, RoutedEventArgs e)
        {
            OdczytajDaneZPliku("dane.txt");
            OdswiezListeMieszkan();
        }

        private void ZamknijToolStripMenuItem_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void PomocToolStripMenuItem_Click(object sender, RoutedEventArgs e)
        {
            Kontakt kontakt = new Kontakt();
            kontakt.ShowDialog();
        }

        private void EdytujToolStripMenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (listViewMieszkania.SelectedItem != null)
            {
                Mieszkania selectedMieszkania = (Mieszkania)listViewMieszkania.SelectedItem;
                Edycja edytujWindow = new Edycja(selectedMieszkania);
                if (edytujWindow.ShowDialog() == true)
                {
                    selectedMieszkania = edytujWindow.EdytowaneMieszkania;
                    OdswiezListeMieszkan();
                }
            }
            else
            {
                MessageBox.Show("Wybierz mieszkania do edycji");
            }
        }

        private void UsunToolStripMenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (listViewMieszkania.SelectedItem != null)
            {
                Mieszkania selectedMieszkania = (Mieszkania)listViewMieszkania.SelectedItem;
                mieszkania.Remove(selectedMieszkania);
                OdswiezListeMieszkan();
            }
            else
            {
                MessageBox.Show("Wybierz mieszkania do usunięcia");
            }
        }

        private void DodajToolStripMenuItem_Click(object sender, RoutedEventArgs e)
        {
            Edycja edytujWindow = new Edycja(new Mieszkania());
            if (edytujWindow.ShowDialog() == true)
            {
                Mieszkania noweMieszkanie = edytujWindow.EdytowaneMieszkania;
                mieszkania.Add(noweMieszkanie);
                OdswiezListeMieszkan();
            }
        }
    }
}