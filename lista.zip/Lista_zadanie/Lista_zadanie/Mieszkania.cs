﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista_zadanie
{
    public class Mieszkania
    {
        public int Id { get; set; }
        public string Osiedle { get; set; }
        public string Adres { get; set; }
        public bool ZGarazem { get; set; }
        public RodzajMieszkania Rodzaj { get; set; }
        public int Metraz { get; set; }
        public bool Dostepnosc { get; set; }
        public string Opis { get; set; }

        public override string ToString()
        {
            return $"{Id}, {Osiedle}, {Adres}, {ZGarazem}, {Rodzaj}, {Metraz}, {Dostepnosc}, {Opis}";
        }
    }

    public enum RodzajMieszkania
    {
        M2,
        M3,
        M4
    }
}

