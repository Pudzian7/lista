﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
namespace Lista_zadanie
{
    /// <summary>
    /// Logika interakcji dla klasy Edycja.xaml
    /// </summary>
    public partial class Edycja : Window
    {
        private Mieszkania edytowaneMieszkania;
        public Mieszkania EdytowaneMieszkania
        {
            get { return edytowaneMieszkania; }
        }

        public Edycja(Mieszkania mieszkania)
        {
            InitializeComponent();
            cmbRodzaj.ItemsSource = Enum.GetValues(typeof(RodzajMieszkania));
            edytowaneMieszkania = mieszkania;
            WypelnijPola(mieszkania);
        }

        private void WypelnijPola(Mieszkania mieszkania)
        {
            txtOsiedle.Text = mieszkania.Osiedle;
            txtAdres.Text = mieszkania.Adres;
            chkZGarazem.IsChecked = mieszkania.ZGarazem;
            cmbRodzaj.SelectedItem = mieszkania.Rodzaj;
            txtMetraz.Text = mieszkania.Metraz.ToString();
            chkDostepnosc.IsChecked = mieszkania.Dostepnosc;
            txtOpis.Text = mieszkania.Opis;
        }



        private void btnZapisz_Click(object sender, RoutedEventArgs e)
        {
            edytowaneMieszkania.Osiedle = txtOsiedle.Text;
            edytowaneMieszkania.Adres = txtAdres.Text;
            edytowaneMieszkania.ZGarazem = (bool)chkZGarazem.IsChecked;
            edytowaneMieszkania.Rodzaj = (RodzajMieszkania)cmbRodzaj.SelectedItem;
            int metraz;
            if (int.TryParse(txtMetraz.Text, out metraz))
            {
                edytowaneMieszkania.Metraz = metraz;
            }
            else
            {
                MessageBox.Show("Podaj poprawny metraż.");
                return;
            }
            edytowaneMieszkania.Dostepnosc = (bool)chkDostepnosc.IsChecked;
            edytowaneMieszkania.Opis = txtOpis.Text;
            this.DialogResult = true;
            Close();
        }

        private void btnAnuluj_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            Close();
        }
        private void chkDostepnosc_Checked(object sender, RoutedEventArgs e)
        {
            if (chkDostepnosc.IsChecked == true)
            {
                MessageBox.Show("Mieszkanie jest dostępne.");
            }
            else
            {
                MessageBox.Show("Mieszkanie nie jest dostępne.");
            }
        }
    }
}

